import { describe, expect, it } from 'vitest'

describe('Testing test', () => {
  it('works!', async () => {
    expect(true).toBe(true)
  })

})